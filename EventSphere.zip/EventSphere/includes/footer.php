<style>

/* Button used to open the chat form - fixed at the bottom of the page */
.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:40px;
	right:40px;
  font-size:25px;
	background-color:cyan;
	color:#FFF;
	border-radius:50px;
	text-align:center;
	box-shadow: 2px 2px 3px #999;
}

.my-float{
	margin-top:22px;
}

/* The popup chat - hidden by default */
.chat-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width textarea */
.form-container textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
  resize: none;
  min-height: 200px;
}

/* When the textarea gets focus, do something */
.form-container textarea:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/send button */
.form-container .btnn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btnn:hover, .open-button:hover {
  opacity: 1;
}

</style>


<footer class="ftco-footer ftco-bg-dark ftco-section">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md">
                <div class="ftco-footer-widget mb-4">
                    <h2 class="ftco-heading-2">EventSphere</h2>
                    <p>Your premier destination for discovering and registering for exciting events. From cultural festivals to professional workshops, we bring diverse experiences right to your fingertips.</p>
                    <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                        <li class="ftco-animate">
                            <a href="https://www.youtube.com/@TEDx" target="_blank">
                                <span class="icon-youtube"></span>
                            </a>
                        </li>
                        <li class="ftco-animate">
                            <a href="https://www.facebook.com/facebookBrasil" target="_blank">
                                <span class="icon-facebook"></span>
                            </a>
                        </li>
                        <li class="ftco-animate">
                            <a href="https://www.instagram.com/instagram/" target="_blank">
                                <span class="icon-instagram"></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md">
                <div class="ftco-footer-widget mb-4 ml-md-5">
                    <h2 class="ftco-heading-2">Event Categories</h2>
                    <ul class="list-unstyled">
                        <li><a href="#workshops" class="py-2 d-block">Workshops & Learning</a></li>
                        <li><a href="#entertainment" class="py-2 d-block">Entertainment</a></li>
                        <li><a href="#lifestyle" class="py-2 d-block">Lifestyle</a></li>
                        <li><a href="#cultural" class="py-2 d-block">Cultural & Festival</a></li>
                        <li><a href="#professional" class="py-2 d-block">Professional & Networking</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md">
                <div class="ftco-footer-widget mb-4">
                    <h2 class="ftco-heading-2">Quick Links</h2>
                    <ul class="list-unstyled">
                        <li><a href="registration.php" class="py-2 d-block">Registration</a></li>
                        <li><a href="index.php" class="py-2 d-block">Home</a></li>
                        <li><a href="#events-section" class="py-2 d-block scroll-link">All Events</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md">
                <div class="ftco-footer-widget mb-4">
                    <h2 class="ftco-heading-2">Contact Info</h2>
                    <div class="block-23 mb-3">
                        <ul>
                            <li><span class="icon icon-map-marker"></span><span class="text">KLE Technological University, Belagavi, Karnataka</span></li>
                            <li><a href="#"><span class="icon icon-phone"></span><span class="text">+91 9876543210 </span></a></li>
                            <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@eventsphere.com</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <p>Made with <i class="icon-heart" aria-hidden="true"></i> by EventSphere Team</p>
            </div>
        </div>
    </div>
</footer>

<!-- Keep the chat button and popup styles -->
<style>
/* Your existing chat button styles remain the same */
</style>

<!-- Keep the chat button and form -->
<button href="#" class="float ftco-animate" onclick="openForm()">
    <span class="icon-chat"></span>
</button>

<div class="chat-popup" id="myForm" style="border-radius:30px;">
    <!-- Your existing chat form remains the same -->
</div>

<!-- Add this script at the bottom of the footer -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle smooth scrolling for links with class 'scroll-link'
    document.querySelectorAll('.scroll-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get the target section id from the href
            const targetId = this.getAttribute('href').split('#')[1];
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});
</script>

    