<body>
  <?php
  include "header.php";
 
  ?>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background: linear-gradient(180deg, rgba(173, 216, 230, 0.8) 0%, rgba(255, 255, 255, 0.9) 100%);">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-9 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
            <div class="text-content" style="padding-left: 40px; border-left: 5px solid #1a365d;">
              <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">
                <strong style="font-size: 3.5rem; color: #1a365d;">EVENT SPHERE</strong>
                <br>
                <span style="font-size: 2.5rem; color: #2c5282; font-weight: 300; letter-spacing: 2px;">Where Moments Become Memories</span>
              </h1>
              <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }" 
                 style="color: #2d4a6d; font-size: 1.2rem; letter-spacing: 3px; text-transform: uppercase;">
                <span style="color: #1a365d;">•</span> Discover 
                <span style="color: #1a365d;">•</span> Experience 
                <span style="color: #1a365d;">•</span> Celebrate
              </p>
              
              <!-- Event Types Display -->
              <div class="event-types-container mt-4">
                  <?php
                  include "db/connect.php";
                  $types_query = "SELECT type_title FROM event_type ORDER BY type_id";
                  $types_result = mysqli_query($con, $types_query);
                  
                  while($type = mysqli_fetch_assoc($types_result)) {
                      echo '<span class="event-type">' . htmlspecialchars($type['type_title']) . '</span>';
                  }
                  ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <style>
        .event-types-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 20px;
        }

        .event-type {
            display: inline-block;
            padding: 6px 15px;
            background: rgba(26, 54, 93, 0.1);
            color: #1a365d;
            border-radius: 20px;
            font-size: 0.9rem;
            letter-spacing: 1px;
            transition: all 0.2s ease;
            cursor: pointer;
            border: 1px solid rgba(26, 54, 93, 0.2);
        }

        .event-type:hover {
            background: rgba(26, 54, 93, 0.2);
            transform: translateY(-2px);
        }
    </style>

    <section class="ftco-section services-section bg-light">
      <div class="container">
        <div class="row d-flex">
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div class="d-flex justify-content-center"><div class="icon"><span class="flaticon-guarantee"></span></div></div>
              <div class="media-body p-2 mt-2">
                <h3 class="heading mb-3">Event Diversity</h3>
                <p>Wide range of events including technical, gaming, on-stage, and off-stage activities to cater to everyone's interests.</p>
              </div>
            </div>      
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div class="d-flex justify-content-center"><div class="icon"><span class="flaticon-like"></span></div></div>
              <div class="media-body p-2 mt-2">
                <h3 class="heading mb-3">Simplified Registration</h3>
                <p>Easy and hassle-free registration process for all participants with instant confirmation.</p>
              </div>
            </div>    
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div class="d-flex justify-content-center"><div class="icon"><span class="flaticon-detective"></span></div></div>
              <div class="media-body p-2 mt-2">
                <h3 class="heading mb-3">Expert Guidance</h3>
                <p>Our expert team is here to guide and assist participants throughout the event journey</p>
              </div>
            </div>      
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div class="d-flex justify-content-center"><div class="icon"><span class="flaticon-support"></span></div></div>
              <div class="media-body p-2 mt-2">
                <h3 class="heading mb-3">Memorable Experiences</h3>
                <p>Create memories that last a lifetime with exciting and engaging activities.</p>
              </div>
            </div>      
          </div>
        </div>
      </div>
    </section>
    <section class=" ftco-destination">
    	<div class="container">
    		<div class="row justify-content-start mb-5 pb-3">
          <div class="col-md-7 heading-section ftco-animate">
            <h2 class="mb-4"><strong>Events</strong> Posters</h2>
          </div>
        </div>
    		<div class="row">
    			<div class="col-md-12">
    				<div class="single-slider owl-carousel ftco-animate">
    					<div class="item">
		    				<div class="destination">
		    					<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(images/EDM.jpg);">
		    						
		    					</a>
		    					
		    				</div>
	    				</div>
	    				<div class="item">
		    				<div class="destination">
		    					<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(images/Esports.jpg);">
		    						
		    					</a>
		    					
		    				</div>
	    				</div>
	    				<div class="item">
		    				<div class="destination">
		    					<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(images/GYM.jpg);">
		    						
		    					</a>
		    					
		    				</div>
	    				</div>
	    				<div class="item">
		    				<div class="destination">
		    					<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(images/Cooking.jpg);">
		    						
		    					</a>
		    					
		    				</div>
	    				</div>
	    				<div class="item">
		    				<div class="destination">
		    					<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(images/Speaker.jpg);">
		    						
		    					</a>
		    					
		    				</div>
	    				</div>
	    				<div class="item">
		    				<div class="destination">
		    					<a href="#" class="img d-flex justify-content-center align-items-center" style="background-image: url(images/Comic.jpg);">
		    						
		    					</a>
		    					
		    				</div>
	    				</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>
    
    <!-- Add this new section for Events heading -->
    <section class="ftco-section" style="padding-bottom: 0;">
        <div class="container">
            <div class="row justify-content-center mb-3">
                <div class="col-md-7 text-center heading-section ftco-animate">
                    <h2 class="mb-2" style="font-size: 3.5rem; font-weight: 700;">
                        <strong>Events</strong>
                    </h2>
                    <p style="color: #2d4a6d; font-size: 1.2rem;">
                        Discover and Register for Exciting Events
                    </p>
                </div>
            </div>
        </div>
    </section>

    <style>
        .event-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 30px;
            background: white;
        }

        .event-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }

        .event-image {
            height: 200px;
            overflow: hidden;
            position: relative;
        }

        .event-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .event-card:hover .event-image img {
            transform: scale(1.1);
        }

        .event-details {
            padding: 20px;
        }

        .event-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
            text-transform: capitalize;
        }

        .event-info {
            color: #666;
            margin-bottom: 15px;
        }

        .event-price {
            font-size: 1.2rem;
            color: #2c3e50;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .register-btn {
            background: #F96D00;
            color: white;
            padding: 10px 25px;
            border-radius: 25px;
            text-decoration: none;
            transition: background 0.3s ease;
            display: inline-block;
        }

        .register-btn:hover {
            background: #e65100;
            color: white;
            text-decoration: none;
        }

        .category-title {
            font-size: 2rem;
            color: #333;
            margin: 40px 0 20px;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
            text-transform: capitalize;
        }

        .category-title::after {
            content: '';
            display: block;
            width: 50px;
            height: 3px;
            background: #F96D00;
            margin: 10px auto;
        }
    </style>

    <section id="events-section" class="ftco-section" style="padding-top: 2rem;">
        <div class="container">
            <?php
            // Fetch event categories
            $category_query = "SELECT DISTINCT type_id, type_title FROM event_type ORDER BY type_id";
            $category_result = mysqli_query($con, $category_query);

            while($category = mysqli_fetch_assoc($category_result)) {
                echo '<h2 class="category-title" data-aos="fade-up">' . htmlspecialchars($category['type_title']) . '</h2>';
                echo '<div class="row">';
                
                // Fetch events for this category
                $events_query = "SELECT * FROM events WHERE type_id = " . $category['type_id'];
                $events_result = mysqli_query($con, $events_query);
                
                while($event = mysqli_fetch_assoc($events_result)) {
                    ?>
                    <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="event-card">
                            <div class="event-image">
                                <img src="images/<?php echo htmlspecialchars($event['img_link']); ?>" 
                                     alt="<?php echo htmlspecialchars($event['event_title']); ?>">
                            </div>
                            <div class="event-details">
                                <h3 class="event-title"><?php echo htmlspecialchars($event['event_title']); ?></h3>
                                <div class="event-info">
                                    <p><i class="fas fa-users"></i> Max Participants: <?php echo htmlspecialchars($event['participents']); ?></p>
                                    <p><i class="fas fa-map-marker-alt"></i> 
                                    <?php
                                        // Specific locations based on event title/type
                                        $eventLocations = array(
                                            'EDM' => 'Goa',
                                            'Gaming' => 'Bangalore, Karnataka',
                                            'Esports' => 'Mumbai, Maharashtra',
                                            'Gym' => 'Delhi, NCR',
                                            'Cooking' => 'Hyderabad, Telangana',
                                            'Speaker' => 'Chennai, Tamil Nadu',
                                            'Comic' => 'Pune, Maharashtra',
                                            'Dance' => 'Kolkata, West Bengal',
                                            'Music' => 'Mumbai, Maharashtra',
                                            'Art' => 'Jaipur, Rajasthan',
                                            'Photography' => 'Belagavi, Karnataka',
                                            'Fashion' => 'Delhi, NCR',
                                            'Food' => 'Kochi, Kerala',
                                            'Sports' => 'Chennai, Tamil Nadu',
                                            'Technology' => 'Bangalore, Karnataka',
                                            // Add more event-location mappings as needed
                                        );

                                        // Get event title or type and find matching location
                                        $eventTitle = strtolower($event['event_title']);
                                        $location = 'Bangalore, Karnataka'; // Default location

                                        foreach ($eventLocations as $keyword => $place) {
                                            if (strpos(strtolower($eventTitle), strtolower($keyword)) !== false) {
                                                $location = $place;
                                                break;
                                            }
                                        }
                                        
                                        echo $location;
                                    ?>
                                    </p>
                                </div>
                                <div class="event-price">
                                    ₹<?php echo htmlspecialchars($event['event_price']); ?>
                                </div>
                                <a href="registration.php?event_id=<?php echo $event['event_id']; ?>" class="register-btn">
                                    Register Now
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
            }
            ?>
        </div>
    </section>

    <section class="ftco-section ftco-counter img" id="section-counter" style="background-image: url(images/bg_1.jpg);">
    	<div class="container">
    		<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
            <h2 class="mb-4" style="font-size: 3.5rem; font-weight: 700;">Some fun facts</h2>
            <span class="subheading" style="font-size: 1.5rem;">More than 100,000 Events hosted</span>
          </div>
        </div>
    		<div class="row justify-content-center">
    			<div class="col-md-10">
		    		<div class="row">
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		                <strong class="number" data-number="10000" style="font-size: 3.5rem;">0</strong>
		                <span style="font-size: 1.2rem; display: block; margin-top: 10px;">Daily Active Users</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		                <strong class="number" data-number="400" style="font-size: 3.5rem;">0</strong>
		                <span style="font-size: 1.2rem; display: block; margin-top: 10px;">At Places</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		                <strong class="number" data-number="87000" style="font-size: 3.5rem;">0</strong>
		                <span style="font-size: 1.2rem; display: block; margin-top: 10px;">Total Users</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18 text-center">
		              <div class="text">
		                <strong class="number" data-number="56400" style="font-size: 3.5rem;">0</strong>
		                <span style="font-size: 1.2rem; display: block; margin-top: 10px;">User Ratings</span>
		              </div>
		            </div>
		          </div>
		        </div>
	        </div>
        </div>
    	</div>
    </section>


   

    <section class="ftco-section testimony-section bg-light">
        <div class="container">
            <div class="row justify-content-start">
                <div class="col-md-5 heading-section ftco-animate">
                    <span class="subheading">Your Premier Event Platform</span>
                    <h2 class="mb-4 pb-3"><strong>Why</strong> Choose EventSphere?</h2>
                    <p>Welcome to EventSphere, where we transform ordinary gatherings into extraordinary experiences. Our platform offers a seamless blend of diverse event categories, from professional workshops to cultural festivals, ensuring there's something for everyone.</p>
                    <p>With our user-friendly registration system, secure payment options, and dedicated support team, we make event participation hassle-free. Join thousands of satisfied attendees who have made unforgettable memories through our events.</p>
                </div>
            </div>
        </div>
    </section>

    

    
		
		

    
  
                                    
<script>
let lastScrollTop = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', function() {
    let currentScroll = window.pageYOffset || document.documentElement.scrollTop;
    
    if (currentScroll > lastScrollTop) {
        // Scrolling down
        navbar.style.transform = 'translateY(-100%)';
        navbar.style.transition = 'transform 0.3s ease-in-out';
    } else {
        // Scrolling up
        navbar.style.transform = 'translateY(0)';
    }
    lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
});
</script>

<style>
.navbar {
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1000;
    transition: transform 0.3s ease-in-out;
    background: transparent !important;
    border: none;
    box-shadow: none !important;
}

/* Remove any backgrounds */
.navbar, 
.navbar-default, 
.navbar.scrolled {
    background: transparent !important;
    background-color: transparent !important;
    box-shadow: none !important;
}

/* Improve text visibility */
.navbar .nav-link,
.navbar .navbar-brand,
.navbar-brand span {
    color: #1a365d !important;
    font-weight: 600 !important;
    font-size: 1.1rem;
    text-shadow: 2px 2px 4px rgba(255, 255, 255, 0.5);
    transition: color 0.3s ease;
}

/* Hover effect */
.navbar .nav-link:hover,
.navbar .navbar-brand:hover {
    color: #2c5282 !important;
    transform: translateY(-1px);
}

/* Active link style */
.navbar .nav-link.active {
    color: #2c5282 !important;
    font-weight: 700 !important;
}

/* Remove body padding */
body {
    padding-top: 0 !important;
}

/* Remove any other backgrounds */
.navbar-collapse,
.navbar-brand,
.navbar-toggler {
    background: transparent !important;
}

.bg-light, 
.bg-white, 
.bg-dark {
    background: transparent !important;
}

/* Style for mobile toggle button */
.navbar-toggler {
    border: 2px solid #1a365d !important;
}

.navbar-toggler-icon {
    background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3e%3cpath stroke='rgba(26, 54, 93, 1)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
}
</style>
                                    