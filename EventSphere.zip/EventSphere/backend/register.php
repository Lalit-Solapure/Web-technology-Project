<?php
include("../db/connect.php");

// Get form data
$fullname = mysqli_real_escape_string($con, $_POST['full_name']);
$email = mysqli_real_escape_string($con, $_POST['email']);
$mobile = mysqli_real_escape_string($con, $_POST['mobile']);
$event = mysqli_real_escape_string($con, $_POST['event']);
$event_type = mysqli_real_escape_string($con, $_POST['event_type']);
$utr_number = mysqli_real_escape_string($con, $_POST['utr_number']);
$event_id = isset($_POST['event_id']) ? mysqli_real_escape_string($con, $_POST['event_id']) : 1;

// SQL query without college and branch
$sql = "INSERT INTO participants (
    event_id,
    fullname,
    email,
    mobile,
    utr_number,
    event,
    event_type
) VALUES (
    '$event_id',
    '$fullname',
    '$email',
    '$mobile',
    '$utr_number',
    '$event',
    '$event_type'
)";

// Execute query
if(mysqli_query($con, $sql)){
    echo json_encode(["success" => true, "event" => $event, "event_type" => $event_type]);
} else {
    echo json_encode(["success" => false, "error" => "Database error: " . mysqli_error($con)]);
}

mysqli_close($con);
?>
