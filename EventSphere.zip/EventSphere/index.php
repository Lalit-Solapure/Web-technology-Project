<?php
session_start();
$ip_add = getenv("REMOTE_ADDR");
include "db/connect.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>EventSphere - Where Moments Become Memories</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <?php
    include "cssjs/css.php";
    ?>
  </head>
  <body>
    <?php
    include "includes/body.php";
    include "includes/footer.php";
    include "cssjs/js.php";
    ?>
  </body>
</html>