<?php
session_start();
$ip_add = getenv("REMOTE_ADDR");
include "db/connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Event Registration</title>
    <?php include "cssjs/css.php"; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Add SweetAlert2 CSS and JS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

    <?php include "includes/header.php"; ?>
    <style>
        .field-border {
            border-radius: 25px !important;
            padding: 12px 20px !important;
        }
        
        select.field-border {
            padding: 12px 20px !important;
            appearance: auto;
        }

        .btn {
            border-radius: 25px !important;
        }
        
        .error {
            color: red;
            font-size: 12px;
        }
        #form-image-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
        #form-image {
            max-width: 80%;
            max-height: 1500px;
            width: auto;
            height: auto;
        }
        body {
            background: linear-gradient(180deg, rgba(173, 216, 230, 0.8) 0%, rgba(255, 255, 255, 0.9) 100%);
            background-attachment: fixed;
        }

        .form-control:focus {
            border-color: #1a365d;
            box-shadow: 0 0 0 0.2rem rgba(26, 54, 93, 0.25);
        }

        button[type="submit"]:hover {
            background: #2c5282 !important;
            transform: translateY(-2px);
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
        }

        .payment-section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .payment-instructions {
            margin: 20px 0;
            padding: 15px;
            border-left: 4px solid #1a365d;
            background: #f8f9fa;
        }

        .payment-steps {
            margin-bottom: 15px;
        }

        .qr-code-container {
            text-align: center;
            padding: 20px;
            border: 2px dashed #1a365d;
            border-radius: 10px;
            margin: 15px 0;
        }

        .qr-code-image {
            max-width: 250px;
            height: auto;
            margin: 10px auto;
        }

        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: transform 0.3s ease-in-out;
        }

        body {
            padding-top: 70px; /* Adjust this value based on your navbar height */
        }
    </style>

    <div class="hero-wrap js-fullheight">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
                <div class="col-md-9 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
                    <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">
                        <strong style="color: #1a365d; font-size: 3.5rem;">Welcome to Event Sphere<br></strong>
                    </h1>
                    <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }" 
                       style="color: #2c5282; font-size: 1.8rem;">
                        Join Our Exciting Events - Register Now!
                    </p>
                </div>
            </div>
        </div>
    </div>

    <section class="ftco-section contact-section ftco-degree-bg">
        <div class="container">
            <div class="col-md-8" id="signup_msg"></div>
            <div class="row block-9">
                <div class="col-md-6 pr-md-5">
                    <form id="signup_form" class="was-validated">
                        <div class="form-group">
                            <label for="full_name" class="mb-2" style="color: #1a365d; font-weight: 500;">Full Name</label>
                            <input type="text" id="full_name" name="full_name" class="form-control field-border" placeholder="Enter your full name">
                            <div id="name_error" class="error"></div>
                        </div>
                        <?php
                        if (isset($_GET['event_id']) && $_GET['event_id'] != '') {
                            $event_id = $_GET['event_id'];
                            echo '<input type="hidden" name="event_id" value="' . htmlspecialchars($event_id) . '" class="form-control field-border" required>';
                        }
                        ?>
                        <div class="form-group">
                            <label for="email" class="mb-2" style="color: #1a365d; font-weight: 500;">Email Address</label>
                            <input type="email" id="email" name="email" class="form-control field-border" placeholder="Enter your email address">
                            <div id="email_error" class="error"></div>
                        </div>
                        <div class="form-group">
                            <label for="mobile" class="mb-2" style="color: #1a365d; font-weight: 500;">Mobile Number</label>
                            <input type="text" id="mobile" class="form-control field-border" name="mobile" placeholder="Enter your 10-digit mobile number">
                            <div id="mobile_error" class="error"></div>
                        </div>
                        <div class="form-group">
                            <label for="event" class="mb-2" style="color: #1a365d; font-weight: 500;">Event Category</label>
                            <select id="event" name="event" class="form-control field-border">
                                <option value="">Select your event category</option>
                                <option value="workshops">Workshops & Learning</option>
                                <option value="entertainment">Entertainment</option>
                                <option value="lifestyle">Lifestyle</option>
                                <option value="cultural">Cultural & Festival</option>
                                <option value="professional">Professional & Networking</option>
                            </select>
                            <div id="event_error" class="error"></div>
                        </div>
                        <div class="form-group">
                            <label for="event_type" class="mb-2" style="color: #1a365d; font-weight: 500;">Specific Event</label>
                            <select id="event_type" name="event_type" class="form-control field-border">
                                <option value="">Choose your specific event</option>
                                <optgroup label="Workshops & Learning">
                                    <option value="photography_workshop">Photography Workshop</option>
                                </optgroup>
                                <optgroup label="Entertainment">
                                    <option value="music_concert">Music Concert</option>
                                    <option value="dance_competition">Dance Competition</option>
                                </optgroup>
                                <optgroup label="Lifestyle">
                                    <option value="cooking_masterclass">Cooking Masterclass</option>
                                    <option value="fitness_workshop">Fitness Workshop</option>
                                </optgroup>
                                <optgroup label="Cultural & Festival">
                                    <option value="art_exhibition">Art Exhibition</option>
                                    <option value="food_festival">Food Festival</option>
                                </optgroup>
                                <optgroup label="Professional & Networking">
                                    <option value="business_networking">Business Networking</option>
                                </optgroup>
                            </select>
                            <div id="event_type_error" class="error"></div>
                        </div>
                        <div class="form-group">
                            <label for="utr_number" class="mb-2" style="color: #1a365d; font-weight: 500;">UTR Number</label>
                            <input type="text" id="utr_number" name="utr_number" class="form-control field-border" placeholder="Enter your UTR number" required>
                            <div id="utr_error" class="error"></div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Complete Registration" name="signup_button" class="btn btn-primary py-3 px-5">
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <div class="payment-section">
                        <h3 class="text-center mb-4" style="color: #1a365d;">Payment Details</h3>
                        
                        <div class="payment-instructions">
                            <h5 style="color: #1a365d;">How to Pay:</h5>
                            <div class="payment-steps">
                                <p><strong>1.</strong> Scan the QR code below using any UPI payment app</p>
                                <p><strong>2.</strong> Enter the amount as per your selected event</p>
                                <p><strong>3.</strong> Complete the payment</p>
                                <p><strong>4.</strong> Enter the UTR number in the registration form</p>
                            </div>
                        </div>

                        <div class="qr-code-container">
                            <h5 style="color: #1a365d;">Scan to Pay</h5>
                            <img src="QR_code.jpg" class="qr-code-image" alt="Payment QR Code">
                            <p class="mt-2"><small class="text-muted">Please save the UTR number after payment</small></p>
                        </div>

                        <div class="alert alert-info" role="alert">
                            <i class="fas fa-info-circle"></i> After completing the payment, please enter the UTR number in the registration form to confirm your registration.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include "includes/footer.php"; ?>
    
    <div id="ftco-loader" class="show fullscreen">
        <svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/>
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/>
        </svg>
    </div>

    <?php include "cssjs/js.php"; ?>

    <script>
    function validateForm() {
        let isValid = true;

        const fields = document.querySelectorAll('.form-control');
        fields.forEach(field => {
            field.classList.remove('is-invalid');
            field.removeAttribute('data-bs-toggle');
            field.removeAttribute('title');
        });

        const fullName = document.getElementById('full_name');
        const fullNamePattern = /^[A-Z][a-z]*(\s[A-Z][a-z]*)*$/;
        if (!fullName.value.match(fullNamePattern)) {
            setTooltipError(fullName, 'Name must start with capital letters and contain only letters and spaces');
            isValid = false;
        }

        const email = document.getElementById('email');
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!email.value.match(emailPattern)) {
            setTooltipError(email, 'Please enter a valid email');
            isValid = false;
        }

        const mobile = document.getElementById('mobile');
        const mobilePattern = /^[0-9]{10}$/;
        if (!mobile.value.match(mobilePattern)) {
            setTooltipError(mobile, 'Please enter a valid 10-digit mobile number');
            isValid = false;
        }

        const event = document.getElementById('event');
        if (!event.value) {
            setTooltipError(event, 'Event is required');
            isValid = false;
        }

        const eventType = document.getElementById('event_type');
        if (!eventType.value) {
            setTooltipError(eventType, 'Event type is required');
            isValid = false;
        }

        const utrNumber = document.getElementById('utr_number');
        const utrPattern = /^[A-Za-z0-9]{10,20}$/;
        if (!utrNumber.value.match(utrPattern)) {
            setTooltipError(utrNumber, 'Please enter a valid UTR number (10-20 alphanumeric characters)');
            isValid = false;
        }

        return isValid;
    }

    function setTooltipError(element, message) {
        element.classList.add('is-invalid');
        element.setAttribute('data-bs-toggle', 'tooltip');
        element.setAttribute('title', message);
        new bootstrap.Tooltip(element);
    }

    document.getElementById('event').addEventListener('change', function() {
        const eventCategory = this.value;
        const eventTypeSelect = document.getElementById('event_type');
        const allEventOptions = eventTypeSelect.getElementsByTagName('option');
        
        // Hide all options first
        for(let option of allEventOptions) {
            option.style.display = 'none';
        }
        
        // Show only relevant options
        switch(eventCategory) {
            case 'workshops':
                showOptionsInGroup('Workshops & Learning');
                break;
            case 'entertainment':
                showOptionsInGroup('Entertainment');
                break;
            case 'lifestyle':
                showOptionsInGroup('Lifestyle');
                break;
            case 'cultural':
                showOptionsInGroup('Cultural & Festival');
                break;
            case 'professional':
                showOptionsInGroup('Professional & Networking');
                break;
            default:
                // Show all options if no category is selected
                for(let option of allEventOptions) {
                    option.style.display = '';
                }
        }
        
        // Reset the event type selection
        eventTypeSelect.value = '';
    });

    function showOptionsInGroup(groupLabel) {
        const eventTypeSelect = document.getElementById('event_type');
        const optgroups = eventTypeSelect.getElementsByTagName('optgroup');
        
        for(let optgroup of optgroups) {
            if(optgroup.label === groupLabel) {
                const options = optgroup.getElementsByTagName('option');
                for(let option of options) {
                    option.style.display = '';
                }
            }
        }
    }

    document.getElementById('signup_form').addEventListener('submit', async function(e) {
        e.preventDefault();

        if (!validateForm()) return;

        try {
            const formData = new FormData(this);
            const response = await fetch('backend/register.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                const eventTypeSelect = document.getElementById('event_type');
                const selectedOption = eventTypeSelect.options[eventTypeSelect.selectedIndex];
                const eventTypeName = selectedOption.text;

                // Directly show success message without any processing state
                Swal.fire({
                    title: 'Registration Successful!',
                    text: `Thank you for registering for ${eventTypeName}`,
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.reset();
                        window.location.href = 'index.php';
                    }
                });
            } else {
                Swal.fire({
                    title: 'Note',
                    text: data.error || 'Something went wrong. Please try again.',
                    icon: 'info',
                    confirmButtonText: 'OK'
                });
            }
        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                title: 'Error!',
                text: 'Something went wrong. Please try again later.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    });

    // Test if SweetAlert is working
    function testSweetAlert() {
        Swal.fire({
            title: 'SweetAlert Test',
            text: 'This is a test message',
            icon: 'info'
        });
    }

    // You can add this button temporarily to test SweetAlert
    // <button onclick="testSweetAlert()" type="button">Test SweetAlert</button>

    let lastScrollTop = 0;
    const navbar = document.querySelector('.navbar');

    window.addEventListener('scroll', function() {
        let currentScroll = window.pageYOffset || document.documentElement.scrollTop;
        
        if (currentScroll > lastScrollTop) {
            // Scrolling down
            navbar.style.transform = 'translateY(-100%)';
            navbar.style.transition = 'transform 0.3s ease-in-out';
        } else {
            // Scrolling up
            navbar.style.transform = 'translateY(0)';
        }
        lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
    });
    </script>
</body>
</html>
